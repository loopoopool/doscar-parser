import re
import numpy as np
from Ploos.Parser import *

def loadEigenval(filename):
    with open(filename, 'r') as f:
        data = f.readlines()
    
    tmp = whitespace_to_semicol(data[5])
    nbands = int(split(tmp)[-1])
    nkpts = int(split(tmp)[-2])
    off = 7
    e = np.zeros((nkpts,nbands))
    k = np.zeros((nkpts,3))
    o = np.zeros((nkpts,nbands))
    for i in range(nkpts):
        k[i] = extract_coord(data[off+i*(2+nbands)])
        for j in range(1,nbands+1):
            tmp = split(data[off+i*(2+nbands)+j])
            e[i,j-1] = float(tmp[1])
            o[i,j-1] = float(tmp[2])

    return k, e, o
